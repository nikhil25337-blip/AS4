#include "loader.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <ELF-executable>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    if (access(argv[1], F_OK) != 0) {
        fprintf(stderr, "Error: file '%s' does not exist.\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    if (access(argv[1], R_OK) != 0) {
        fprintf(stderr, "Error: file '%s' is not readable.\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    load_and_run_elf(argv[1]);
    loader_cleanup();
    return 0;
}
