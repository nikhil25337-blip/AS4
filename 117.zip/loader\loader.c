#include "loader.h"

typedef struct PageNode {
    void *addr;
    struct PageNode *next;
} PageNode;

static void *g_file_buf = NULL;
static size_t g_file_size = 0;
static Elf32_Ehdr *g_ehdr = NULL;
static Elf32_Phdr *g_phdr = NULL;
static PageNode *g_pages_head = NULL;
static int g_page_faults = 0;
static int g_page_allocs = 0;
static size_t g_frag_bytes = 0;

static int is_page_mapped(void *addr) {
    PageNode *curr = g_pages_head;
    while (curr) {
        if (curr->addr == addr) return 1;
        curr = curr->next;
    }
    return 0;
}

static void sigsegv_handler(int sig, siginfo_t *info, void *ctx) {
    (void)sig;
    (void)ctx;
    g_page_faults++;

    uintptr_t fault_addr = (uintptr_t)info->si_addr;
    Elf32_Phdr *seg = NULL;

    for (int i = 0; i < (int)g_ehdr->e_phnum; i++) {
        if (g_phdr[i].p_type != PT_LOAD) continue;
        uintptr_t seg_start = (uintptr_t)g_phdr[i].p_vaddr;
        uintptr_t seg_end = seg_start + (uintptr_t)g_phdr[i].p_memsz;
        if (fault_addr >= seg_start && fault_addr < seg_end) {
            seg = &g_phdr[i];
            break;
        }
    }

    if (!seg) {
        signal(SIGSEGV, SIG_DFL);
        raise(SIGSEGV);
        return;
    }

    uintptr_t page_offset = (fault_addr & ~(PAGE_SIZE - 1)) - (seg->p_vaddr & ~(PAGE_SIZE - 1));
    void *p_vaddr = (void *)((seg->p_vaddr & ~(PAGE_SIZE - 1)) + page_offset);

    if (is_page_mapped(p_vaddr)) {
        signal(SIGSEGV, SIG_DFL);
        raise(SIGSEGV);
        return;
    }

    int prot = PROT_READ | PROT_WRITE;
    if (seg->p_flags & PF_X) prot |= PROT_EXEC;

    void *mapped = mmap(p_vaddr, PAGE_SIZE, prot, MAP_ANONYMOUS | MAP_PRIVATE | MAP_FIXED, -1, 0);
    if (mapped == MAP_FAILED) {
        signal(SIGSEGV, SIG_DFL);
        raise(SIGSEGV);
        return;
    }

    PageNode *node = (PageNode *)malloc(sizeof(PageNode));
    if (!node) {
        munmap(mapped, PAGE_SIZE);
        signal(SIGSEGV, SIG_DFL);
        raise(SIGSEGV);
        return;
    }
    node->addr = mapped;
    node->next = g_pages_head;
    g_pages_head = node;
    g_page_allocs++;

    uintptr_t page_start = (uintptr_t)p_vaddr;
    uintptr_t page_end = page_start + PAGE_SIZE;
    uintptr_t seg_file_start = (uintptr_t)seg->p_vaddr;
    uintptr_t seg_file_end = seg_file_start + (uintptr_t)seg->p_filesz;

    uintptr_t copy_start = (page_start > seg_file_start) ? page_start : seg_file_start;
    uintptr_t copy_end = (page_end < seg_file_end) ? page_end : seg_file_end;

    if (copy_start < copy_end) {
        size_t seg_off = copy_start - seg_file_start;
        size_t file_off = (size_t)seg->p_offset + seg_off;
        memcpy((void *)copy_start, (char *)g_file_buf + file_off, copy_end - copy_start);
    }

    uintptr_t seg_mem_end = (uintptr_t)seg->p_vaddr + (uintptr_t)seg->p_memsz;
    if (page_end > seg_mem_end) {
        uintptr_t waste_start = (seg_mem_end > page_start) ? seg_mem_end : page_start;
        g_frag_bytes += (page_end - waste_start);
    }
}

void load_and_run_elf(char *exe) {
    int fd = open(exe, O_RDONLY);
    if (fd < 0) {
        fprintf(stderr, "Error opening '%s': %s\n", exe, strerror(errno));
        exit(EXIT_FAILURE);
    }

    off_t fsize = lseek(fd, 0, SEEK_END);
    if (fsize <= 0) {
        fprintf(stderr, "Error: '%s' empty or invalid\n", exe);
        close(fd);
        exit(EXIT_FAILURE);
    }
    if (lseek(fd, 0, SEEK_SET) == (off_t)-1) {
        perror("lseek");
        close(fd);
        exit(EXIT_FAILURE);
    }

    g_file_size = (size_t)fsize;
    g_file_buf = malloc(g_file_size);
    if (!g_file_buf) {
        perror("malloc");
        close(fd);
        exit(EXIT_FAILURE);
    }

    size_t total_read = 0;
    while (total_read < g_file_size) {
        ssize_t n = read(fd, (char *)g_file_buf + total_read, g_file_size - total_read);
        if (n <= 0) {
            perror("read");
            free(g_file_buf);
            close(fd);
            exit(EXIT_FAILURE);
        }
        total_read += (size_t)n;
    }
    close(fd);

    if (g_file_size < sizeof(Elf32_Ehdr)) {
        fprintf(stderr, "Error: file too small for ELF\n");
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    g_ehdr = (Elf32_Ehdr *)g_file_buf;

    if (g_ehdr->e_ident[EI_MAG0] != ELFMAG0 || g_ehdr->e_ident[EI_MAG1] != ELFMAG1 ||
        g_ehdr->e_ident[EI_MAG2] != ELFMAG2 || g_ehdr->e_ident[EI_MAG3] != ELFMAG3) {
        fprintf(stderr, "Error: '%s' is not a valid ELF file\n", exe);
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    if (g_ehdr->e_ident[EI_CLASS] != ELFCLASS32) {
        fprintf(stderr, "Error: only 32-bit ELF supported\n");
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    if (g_ehdr->e_type != ET_EXEC) {
        fprintf(stderr, "Error: not an executable\n");
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    if (g_ehdr->e_phoff == 0 || g_ehdr->e_phnum == 0) {
        fprintf(stderr, "Error: no program headers\n");
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    if ((size_t)g_ehdr->e_phoff + g_ehdr->e_phnum * sizeof(Elf32_Phdr) > g_file_size) {
        fprintf(stderr, "Error: program header table extends beyond file\n");
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    g_phdr = (Elf32_Phdr *)((char *)g_file_buf + g_ehdr->e_phoff);

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = sigsegv_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGSEGV, &sa, NULL) != 0) {
        perror("sigaction");
        free(g_file_buf);
        exit(EXIT_FAILURE);
    }

    int (*_start_func)(void) = (int (*)(void))(uintptr_t)g_ehdr->e_entry;
    int retval = _start_func();

    printf("User _start return value %d\n", retval);
    printf("Total page faults: %d\n", g_page_faults);
    printf("Total page allocations: %d\n", g_page_allocs);
    printf("Total internal fragmentation: %.2f KB\n", (float)g_frag_bytes / 1024.0);
}

void loader_cleanup(void) {
    PageNode *curr = g_pages_head;
    while (curr) {
        PageNode *temp = curr;
        munmap(curr->addr, PAGE_SIZE);
        curr = curr->next;
        free(temp);
    }
    g_pages_head = NULL;

    if (g_file_buf) {
        free(g_file_buf);
        g_file_buf = NULL;
        g_file_size = 0;
        g_ehdr = NULL;
        g_phdr = NULL;
    }

    g_page_faults = 0;
    g_page_allocs = 0;
    g_frag_bytes = 0;
}
